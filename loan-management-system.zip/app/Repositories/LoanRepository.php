<?php

namespace App\Repositories;

use App\Models\Loan;

class LoanRepository implements LoanRepositoryInterface
{
    protected $loan;

    public function __construct(Loan $loan)
    {
        $this->loan = $loan;
    }

    public function getAllLoans()
    {
        return $this->loan->all();
    }

    public function getLoanById($loanId)
    {
        try {
            $loan = $this->loan->findOrFail($loanId);
            return response()->json($loan, 200);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'message' => 'Loan not found.',
                'loan_id' => $loanId,
            ], 404);
        }
    }

    public function createLoan(array $loanData)
    {
        return $this->loan->create($loanData);
    }

    public function updateLoan($loanId, array $loanData)
    {
        $loan = $this->getLoanById($loanId);
        $loan->update($loanData);
        return $loan;
    }

    public function deleteLoan($loanId)
    {
        $loan = $this->getLoanById($loanId);
        return $loan->delete();
    }
}
